
#include "app.h"

int main(int argc, char** argv) {
    return nls::App{}.run(argc, argv);
}
