Sample text for default listing tests.
