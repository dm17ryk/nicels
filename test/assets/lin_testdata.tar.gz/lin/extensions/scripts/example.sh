#!/bin/sh
echo script
