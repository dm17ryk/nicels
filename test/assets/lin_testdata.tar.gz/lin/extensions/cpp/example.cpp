#include <iostream>
int main() { std::cout << "hi" << std::endl; }
