#!/usr/bin/env bash
echo "Executed"
